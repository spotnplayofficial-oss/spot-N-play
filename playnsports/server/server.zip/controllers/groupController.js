import asyncHandler from 'express-async-handler';
import Group from '../models/Group.js';
import Player from '../models/Player.js';
import Conversation from '../models/Conversation.js';
import { getIO } from '../socket/io.js';
import { scrubNestedPhone } from '../utils/phonePrivacy.js';

const emitGroupUpdate = (group) => {
  try {
    const io = getIO();
    if (io) {
      io.emit('group_updated', group);
    }
  } catch (err) {
    console.error('Error emitting group_updated socket event:', err);
  }
};

const createGroup = asyncHandler(async (req, res) => {
  const { name, sport, maxMembers, joiningDeadline, coordinates } = req.body;

  const validCoordinates =
    Array.isArray(coordinates) && coordinates.length === 2 && !isNaN(coordinates[0]) && !isNaN(coordinates[1])
      ? [Number(coordinates[0]), Number(coordinates[1])]
      : [75.7046194, 31.2554066];

  const group = await Group.create({
    name,
    sport: (sport || 'cricket').toLowerCase(),
    createdBy: req.user._id,
    members: [req.user._id],
    maxMembers: maxMembers || 10,
    joiningDeadline: new Date(joiningDeadline),
    location: { type: 'Point', coordinates: validCoordinates },
    isOpen: true,
  });

  // Auto-create group conversation for backend messaging
  await Conversation.create({
    type: 'group',
    group: group._id,
    participants: [req.user._id],
  });

  const populatedGroup = await Group.findById(group._id)
    .populate('createdBy', 'name avatar')
    .populate('members', 'name avatar')
    .populate('invitations.user', 'name avatar');

  emitGroupUpdate(populatedGroup);

  res.status(201).json(populatedGroup);
});

const getMyGroups = asyncHandler(async (req, res) => {
  const groups = await Group.find({
    members: req.user._id,
  })
    .populate('createdBy', 'name avatar')
    .populate('members', 'name avatar')
    .populate('invitations.user', 'name avatar')
    .sort({ createdAt: -1 });

  res.json(groups);
});

const getNearbyGroups = asyncHandler(async (req, res) => {
  const { longitude, latitude, radius = 5000, sport } = req.query;

  const query = {
    isOpen: true,
    joiningDeadline: { $gt: new Date() },
    location: {
      $near: {
        $geometry: {
          type: 'Point',
          coordinates: [parseFloat(longitude), parseFloat(latitude)],
        },
        $maxDistance: parseFloat(radius),
      },
    },
  };

  if (sport) query.sport = sport;

  const groups = await Group.find(query)
    .populate('createdBy', 'name avatar')
    .populate('members', 'name avatar')
    .populate('invitations.user', 'name avatar');

  res.json(groups);
});

const invitePlayer = asyncHandler(async (req, res) => {
  const { userId } = req.body;

  const group = await Group.findById(req.params.id);

  if (!group) {
    res.status(404);
    throw new Error('Group not found');
  }

  if (group.createdBy.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Only group creator can invite players');
  }

  const alreadyInvited = group.invitations.find(
    (inv) => inv.user && inv.user.toString() === userId
  );

  if (alreadyInvited) {
    res.status(400);
    throw new Error('Player already invited');
  }

  const alreadyMember = group.members.find(
    (m) => m && m.toString() === userId
  );

  if (alreadyMember) {
    res.status(400);
    throw new Error('Player already a member');
  }

  group.invitations.push({ user: userId, status: 'pending' });
  await group.save();

  const populatedGroup = await Group.findById(group._id)
    .populate('createdBy', 'name avatar')
    .populate('members', 'name avatar')
    .populate('invitations.user', 'name avatar');

  try {
    const io = getIO();
    if (io) {
      io.to(`user_${userId}`).emit('group_invitation', populatedGroup);
      io.emit('group_updated', populatedGroup);
    }
  } catch (err) {
    console.error('Error emitting group_invitation socket event:', err);
  }

  res.json({ message: 'Invitation sent ✅', group: populatedGroup });
});

const respondToInvitation = asyncHandler(async (req, res) => {
  const { response } = req.body;

  const group = await Group.findById(req.params.id);

  if (!group) {
    res.status(404);
    throw new Error('Group not found');
  }

  const invitation = group.invitations.find(
    (inv) => inv.user.toString() === req.user._id.toString()
  );

  if (!invitation) {
    res.status(404);
    throw new Error('Invitation not found');
  }

  invitation.status = response;

  if (response === 'accepted') {
    if (group.members.length >= group.maxMembers) {
      res.status(400);
      throw new Error('Group is full');
    }
    group.members.push(req.user._id);

    // Sync conversation participants so group chat appears for this user
    await Conversation.updateOne(
      { type: 'group', group: group._id },
      { $addToSet: { participants: req.user._id } }
    );
  }

  await group.save();

  const updatedGroup = await Group.findById(group._id)
    .populate('createdBy', 'name avatar')
    .populate('members', 'name avatar')
    .populate('invitations.user', 'name avatar');

  emitGroupUpdate(updatedGroup);

  res.json(updatedGroup);
});

const joinGroup = asyncHandler(async (req, res) => {
  const group = await Group.findById(req.params.id);
  if (!group) { res.status(404); throw new Error('Group not found'); }
  if (!group.isOpen) { res.status(400); throw new Error('Group is closed'); }

  // ← DUPLICATE CHECK
  const alreadyMember = group.members.some(
    (m) => m.toString() === req.user._id.toString()
  );
  if (alreadyMember) {
    res.status(400);
    throw new Error('You are already a member of this group');
  }

  if (group.members.length >= group.maxMembers) {
    res.status(400);
    throw new Error('Group is full');
  }

  group.members.push(req.user._id);
  await group.save();

  // Sync conversation participants
  await Conversation.updateOne(
    { type: 'group', group: req.params.id },
    { $addToSet: { participants: req.user._id } }
  );

  const updatedGroup = await Group.findById(group._id)
    .populate('createdBy', 'name avatar')
    .populate('members', 'name avatar')
    .populate('invitations.user', 'name avatar');

  emitGroupUpdate(updatedGroup);

  res.json(updatedGroup);
});

const leaveGroup = asyncHandler(async (req, res) => {
  const group = await Group.findById(req.params.id);

  if (!group) {
    res.status(404);
    throw new Error('Group not found');
  }

  const isCreator = group.createdBy.toString() === req.user._id.toString();
  if (isCreator) {
    group.isOpen = false;
  }

  group.members = group.members.filter(
    (m) => m.toString() !== req.user._id.toString()
  );

  await group.save();

  // Sync conversation participants
  await Conversation.updateOne(
    { type: 'group', group: req.params.id },
    { $pull: { participants: req.user._id } }
  );

  const updatedGroup = await Group.findById(group._id)
    .populate('createdBy', 'name avatar')
    .populate('members', 'name avatar')
    .populate('invitations.user', 'name avatar');

  emitGroupUpdate(updatedGroup);

  res.json(updatedGroup);
});

const closeGroup = asyncHandler(async (req, res) => {
  const group = await Group.findOne({ _id: req.params.id, createdBy: req.user._id });

  if (!group) {
    res.status(404);
    throw new Error('Group not found or unauthorized');
  }

  group.isOpen = false;
  await group.save();

  const updatedGroup = await Group.findById(group._id)
    .populate('createdBy', 'name avatar')
    .populate('members', 'name avatar')
    .populate('invitations.user', 'name avatar');

  emitGroupUpdate(updatedGroup);

  res.json(updatedGroup);
});

const getMyInvitations = asyncHandler(async (req, res) => {
  const groups = await Group.find({
    'invitations.user': req.user._id,
    'invitations.status': 'pending',
  })
    .populate('createdBy', 'name avatar')
    .populate('members', 'name avatar')
    .populate('invitations.user', 'name avatar');

  res.json(groups);
});

// Add new controller function
const getInvitablePlayers = asyncHandler(async (req, res) => {
  const group = await Group.findById(req.params.id);
  if (!group) { res.status(404); throw new Error('Group not found'); }
  if (group.createdBy.toString() !== req.user._id.toString()) {
    res.status(403); throw new Error('Only creator can invite');
  }

  // Get all players except already members and already invited
  const excludeIds = [
    ...group.members.map(m => m.toString()),
    ...group.invitations.map(i => i.user.toString()),
  ];

  const players = await Player.find({
    user: { $nin: excludeIds },
    isAvailable: true,
  }).populate('user', 'name avatar phone hidePhoneNumber');

  res.json(scrubNestedPhone(players, 'user', req.user._id));
});

const removeMember = asyncHandler(async (req, res) => {
  const { userId } = req.body;
  const group = await Group.findById(req.params.id);
  if (!group) { res.status(404); throw new Error('Group not found'); }
  if (group.createdBy.toString() !== req.user._id.toString()) {
    res.status(403); throw new Error('Only creator can remove members');
  }
  if (userId === group.createdBy.toString()) {
    res.status(400); throw new Error('Cannot remove group creator');
  }
  group.members = group.members.filter(m => m.toString() !== userId);
  await group.save();

  // Sync conversation participants
  await Conversation.updateOne(
    { type: 'group', group: req.params.id },
    { $pull: { participants: userId } }
  );

  const updatedGroup = await Group.findById(group._id)
    .populate('createdBy', 'name avatar')
    .populate('members', 'name avatar')
    .populate('invitations.user', 'name avatar');

  try {
    const io = getIO();
    if (io) {
      io.to(`user_${userId}`).emit('user_removed_from_group', {
        groupId: group._id.toString(),
        groupName: group.name,
        sport: group.sport,
        creatorName: req.user.name,
        removedUserId: userId,
      });
    }
  } catch (err) {
    console.error('Error emitting user_removed_from_group socket event:', err);
  }

  emitGroupUpdate(updatedGroup);

  res.json(updatedGroup);
});


const getGroupById = asyncHandler(async (req, res) => {
  const group = await Group.findById(req.params.id)
    .populate('createdBy', 'name avatar')
    .populate('members', 'name avatar')
    .populate('invitations.user', 'name avatar');

  if (!group) {
    res.status(404);
    throw new Error('Group not found');
  }

  res.json(group);
});

export {
  createGroup,
  getMyGroups,
  getNearbyGroups,
  getGroupById,
  invitePlayer,
  respondToInvitation,
  joinGroup,
  leaveGroup,
  closeGroup,
  getMyInvitations,
  getInvitablePlayers,
  removeMember,
};